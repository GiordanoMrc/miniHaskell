package br.unb.cic.mhs

trait Valor extends Expressao