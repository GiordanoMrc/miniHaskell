package br.unb.cic.mhs

abstract class ExpressaoBinaria(val lhs : Expressao, val rhs : Expressao) extends Expressao