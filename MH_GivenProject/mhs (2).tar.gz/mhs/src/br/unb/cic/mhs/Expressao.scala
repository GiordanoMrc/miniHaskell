package br.unb.cic.mhs

trait Expressao {
  def avaliar() : Valor
}